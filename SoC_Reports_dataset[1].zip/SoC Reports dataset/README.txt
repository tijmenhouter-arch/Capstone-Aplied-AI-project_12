METADATA:
--------
This folder is part of the repository of Data from 'Unveiling Climate-Adaptive World Heritage Management Strategies: the Netherlands as a Case Study'.

The folder consists of three Excel files:
1) Edges_SoC Reports: Spreadsheet containing weighted connections from source to target nodes.
2) Nodes_SoC Reports: Spreadsheet with registered individual nodes, with their ID and names. They are classified under themes and types.
3) SoC Reports dataset: The workbook consists of multiple spreadsheets. The 'Code_structure' sheet outlines the sub-themes, their abbreviations, and the themes they belong to. For the 'COUNT' sheet, please note that it contains the formula COUNTIFS that calculate occurrence frequencies of codes from each document. These values are only visible when editing is enabled. If the file is opened in read-only mode or protected view, the formula results may not be displayed. Please enable editing to access the calculated data. Other separate spreadsheets each represent a single World Heritage property's State of Conservation (SoC) Report by the State Parties, containing associated codes and reference texts extracted from its SoC Report.

CREATORS:
Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
ORCID: 0009-0002-5231-5517 

Nan Bai, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; N.Bai@tudelft.nl
ORCID: 0000-0001-7637-3629

Ana Pereira Roders, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; A.R.Pereira-Roders@tudelft.nl
ORCID: 0000-0003-2571-9882

LICENSE: 
Attribution 4.0 International (CC BY 4.0)
--------
INFORMATION AND CONTACT
--------
This README is prepared in May 2025 by Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
