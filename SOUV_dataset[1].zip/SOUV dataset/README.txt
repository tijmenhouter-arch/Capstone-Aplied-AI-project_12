METADATA:
--------
This folder is part of the repository of Data from 'Unveiling Climate-Adaptive World Heritage Management Strategies: the Netherlands as a Case Study'.

The folder consists of one file:
1) SOUV dataset: The 'Code_structure' spreadsheet describes codes and their implications, along with their associated sub-themes and themes. Other separate spreadsheets each represent a single World Heritage property's Statement of Outstanding Universal Value (SOUV), containing associated codes and reference texts extracted from its SOUV. The 'Sankey_dataset' sheet outlines calculated occurrence frequencies of codes, sub-themes, and themes, serving as the basis for generating the SOUV Sankey diagram. For this sheet, please note that it contains the formulas COUNTIF and SUM to calculate occurrence frequencies of codes from each SOUV document. These values are only visible when editing is enabled. If the file is opened in read-only mode or protected view, the formula results may not be displayed. Please enable editing to access the calculated data.


CREATORS:
Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
ORCID: 0009-0002-5231-5517 

Nan Bai, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; N.Bai@tudelft.nl
ORCID: 0000-0001-7637-3629

Ana Pereira Roders, Department of Architectural Engineering and Technology, Delft University of Technology, 2628 BZ Delft, the Netherlands; A.R.Pereira-Roders@tudelft.nl
ORCID: 0000-0003-2571-9882

LICENSE: 
Attribution 4.0 International (CC BY 4.0)

INFORMATION AND CONTACT
--------
This README is prepared in May 2025 by Kai Cheang, Department of Archaeological Heritage and Society, Leiden University, 2333 CC Leiden, the Netherlands; s3423948@vuw.leidenuniv.nl
